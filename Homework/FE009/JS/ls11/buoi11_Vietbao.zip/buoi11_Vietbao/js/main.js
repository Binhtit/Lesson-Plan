import { collections, ourTeam, provides } from "./data.js";

let collectionsList = document.querySelector('.collections-all');
let teamList = document.querySelector('.our-teams');
let provideList = document.querySelector('.provide');
let modal = document.querySelector('.modal-detail');
let closeModal = document.querySelector('.modal-close');
let valueTitle = document.querySelector('.value-title');
let valueDesc = document.querySelector('.value-desc');
let popupUpdated = document.querySelector('.popup-updated');
let idItem = document.querySelector('.idItem').innerText;

window.handleEdit = handleEdit;
window.handleSave = handleSave;
window.handleCloseModal = handleCloseModal;

renderCollections(collections)
renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)

function handleSave() {
  collections[idItem - 1].title = valueTitle.value
  collections[idItem - 1].desc = valueDesc.value
  modal.classList.remove('show')
  popupUpdated.classList.add('show')
  renderCollections(collections);
  setTimeout(removePopup, 2000);
}

function removePopup() {
  popupUpdated.classList.remove('show')
}

function handleCloseModal() {
  modal.classList.remove('show')
}

function renderCollections(collections) {
  let listEleCollection = document.querySelectorAll('.collections-all .collection-item');
  for (let idx = 0; idx < listEleCollection.length; idx++) {
    listEleCollection[idx].remove();
  }
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    collectionItem.classList.add('collection-item')
    collectionItem.dataset.id = val.id;
    collectionItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
        <div class="btn btn-success btn-edit" onclick="handleEdit(${val.id})">
          Edit 
        </div>
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.title}</h3>
        <div class="box-excerpt">${val.desc}</div>
      </div>
    `
    collectionsList.appendChild(collectionItem);
  });
}

function handleEdit(numberID) {

  valueTitle.value = collections[numberID - 1].title
  valueDesc.value = collections[numberID - 1].desc
  idItem = numberID;
  modal.classList.add('show');

}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    teamItem.classList.add('item')
    teamItem.dataset.id = val.id;
    teamItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `
    ele.appendChild(teamItem);
  });
}