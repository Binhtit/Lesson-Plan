<template>
  <header class="header">
    <div class="header__logo">
      <a href="/" id="header__logo--img">
        <img src="../assets/logo-silika.png" alt="" />
      </a>
      <a href="#" class="header__logo--btn">We’re Hiring</a>
    </div>
    <ul class="header__nav">
      <li v-for="menu in menus" :key="menu.id">
        <a :href="menu.link">
          {{ menu.name }}
          <font-awesome-icon
            v-if="menu.child"
            icon="fa-solid fa-chevron-down"
          />
          <ul class="sub-menu" v-if="menu.child">
            <li v-for="subMenu in menu.child" :key="subMenu.id">
              <a :href="subMenu.link">{{ subMenu.name }}</a>
            </li>
          </ul>
          <!-- <span v-if="menu.child">child</span>
          <i v-if="menu.child" class="fa-solid fa-chevron-down"></i> -->
        </a>
      </li>
    </ul>
    <div class="header__right">
      <a href="#" class="header__right--login">Login</a>
      <a href="" class="header__right--button">Get Started</a>
    </div>
  </header>
</template>

<script>
import { DATA_HEADER } from "../resource/data-header.js";

export default {
  data() {
    return {
      menus: DATA_HEADER,
    };
  },
};
</script>

<style lang="scss">
@import "../assets/scss/_base.scss";
// @import "../assets/scss/_mixin.scss";
// @import "../assets/scss/_extend.scss";
// @import "../assets/scss/variable.scss";
// @import "../assets/scss/mixin.scss";
// @import "../assets/scss/extend.scss";

.header {
  @include flex-box(center, space-between);
  padding: 23px 133px;
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  &__logo {
    @include flex-box(center, "");
    &--btn {
      @include style-button(#f22e52);
      padding: 8px 11px;
      margin-left: 6px;
    }
  }
  &__nav {
    @include flex-box(center, "");
    & > li {
      margin-right: 24px;
      & > a {
        @extend .style-a;
        position: relative;
        padding: 10px 0;
        &::after {
          content: "";
          width: 0%;
          height: 1px;
          background: $textColor;
          display: block;
          position: absolute;
          top: 32px;
          left: 0;
          transition: all 0.35s ease;
        }
        &:hover {
          &::after {
            width: 100%;
          }
          .sub-menu {
            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
          }
        }
        ul.sub-menu {
          position: absolute;
          top: 100%;
          min-width: 150px;
          background: #fff;
          padding: 10px;
          clip-path: polygon(0 0, 100% 0, 100% 0, 0 0);
          transition: all 0.3s ease;
          border-radius: 4px;
          a {
            padding: 4px 0;
            color: $textColor;
            display: inline-block;
          }
        }
      }
      &:last-child {
        margin-right: 0;
      }
    }
  }
  &__right {
    &--login {
      @extend .style-a;
    }
    &--button {
      @include style-button($color--lightGreen);
      margin-left: 16px;
    }
  }
}
</style>