import { collections, ourTeam, provides, testimonials } from "./data.js";

let collectionsList = document.querySelector('.collections-all');
let teamList = document.querySelector('.our-teams');
let provideList = document.querySelector('.provide');
let modal = document.querySelector('.modal-detail');
let modalAdd = document.querySelector('.modal-add');
let valueTitle = document.querySelector('.value-title');
let valueDesc = document.querySelector('.value-desc');
let valueTitleAdd = document.querySelector('.value-title-add');
let valueDescAdd = document.querySelector('.value-desc-add');
let popupUpdated = document.querySelector('.popup-updated');
let popupAdd = document.querySelector('.popup-added');
let testimonial = document.querySelector('.testimonials')
let idItem = '';

window.handleEdit = handleEdit;
window.handleSave = handleSave;
window.handleCloseModal = handleCloseModal;
window.handleAdd = handleAdd;
window.handleAddCollection = handleAddCollection;

renderCollections(collections)
renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)
renderTestimonials(testimonials, testimonial)

function handleSave() {
  collections[idItem - 1].title = valueTitle.value
  collections[idItem - 1].desc = valueDesc.value
  modal.classList.remove('show')
  popupUpdated.classList.add('show')
  renderCollections(collections);
  setTimeout(removePopup, 2000);
}

function handleAddCollection() {
  console.log(valueTitle.value);
  if (valueTitleAdd.value || valueDescAdd.value) {
    const newCollection = {
      id: collections.length + 1,
      title: valueTitleAdd.value,
      thumbnail: collections[getRandomIntImg(9)].thumbnail,
      desc: valueDescAdd.value,
    }
    collections.push(newCollection)
    valueTitleAdd.value = '';
    valueDescAdd.value = '';
    popupAdd.classList.add('show')
    handleCloseModal();
    renderCollections(collections)
    setTimeout(removePopup, 2000);
  }
}

function getRandomIntImg(int) {
  return Math.floor(Math.random() * int);
}

function handleAdd() {
  modalAdd.classList.add('show')
}

function removePopup() {
  popupUpdated.classList.remove('show')
  popupAdd.classList.remove('show')
}

function handleCloseModal(params) {
  if (params == 'modalDetail') {
    modal.classList.remove('show')
  } else {
    modalAdd.classList.remove('show')
  }
}

function renderCollections(collections) {
  let listEleCollection = document.querySelectorAll('.collections-all .collection-item');
  for (let idx = 0; idx < listEleCollection.length; idx++) {
    listEleCollection[idx].remove();
  }
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    collectionItem.classList.add('collection-item')
    collectionItem.dataset.id = val.id;
    collectionItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
        <div class="btn btn-success btn-edit" onclick="handleEdit(${val.id})">
          Edit 
        </div>
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.title}</h3>
        <div class="box-excerpt">${val.desc}</div>
      </div>
    `
    collectionsList.appendChild(collectionItem);
  });
}

function handleEdit(numberID) {
  valueTitle.value = collections[numberID - 1].title
  valueDesc.value = collections[numberID - 1].desc
  idItem = numberID;
  modal.classList.add('show');
}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    teamItem.classList.add('item')
    teamItem.dataset.id = val.id;
    teamItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `
    ele.appendChild(teamItem);
  });
}


function renderTestimonials(array, ele) {
  array.forEach(val => {
    let testItem = document.createElement('div');
    testItem.classList.add('item')
    testItem.dataset.id = val.id;
    testItem.innerHTML = `
    <div class="top">
      <div class="avt">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="name">
        <div class="name-top">${val.name}</div>
        <div class="name-bottom">${val.nameAcc}</div>
      </div>
    </div>
    <div class="bottom">${val.desc}</div>
    `
    ele.appendChild(testItem);
  });
}