let collectionsList = document.querySelector('.collections-all');
let teamList = document.querySelector('.our-teams');
let provideList = document.querySelector('.provide');

renderCollections(collections)
renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)

function renderCollections(collections) {
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    collectionItem.classList.add('collection-item')
    collectionItem.dataset.id = val.id;
    collectionItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.title}</h3>
        <div class="box-excerpt">${val.desc}</div>
      </div>
    `
    collectionsList.appendChild(collectionItem);
  });
}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    teamItem.classList.add('item')
    teamItem.dataset.id = val.id;
    teamItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `
    ele.appendChild(teamItem);
  });
}