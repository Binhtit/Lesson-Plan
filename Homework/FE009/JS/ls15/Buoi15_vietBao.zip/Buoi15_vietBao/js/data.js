export const collections = [
  {
    id: 1,
    title: "Moonbirds",
    thumbnail: "./img/c1.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 2,
    title: "Clone X - X Takashi Murakami",
    thumbnail: "../img/c2.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 3,
    title: "Mutant Ape Yacht Club",
    thumbnail: "../img/c3.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  },
  {
    id: 4,
    title: " 'MOAR' by Joan Cornella",
    thumbnail: "../img/c4.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 5,
    title: "Doodles",
    thumbnail: "../img/c5.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 6,
    title: "KIWAMI Genesis",
    thumbnail: "../img/c6.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  },
  {
    id: 7,
    title: "Arcade Land",
    thumbnail: "../img/c7.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 8,
    title: "Goons of Balatroon",
    thumbnail: "../img/c8.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 9,
    title: "Meta Toy DragonZ",
    thumbnail: "./img/c9.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  }
]
export const ourTeam = [
  {
    id: 1,
    title: "Guy Hawkins",
    thumbnail: "./img/o1.png",
    desc: "CEO",
  },
  {
    id: 2,
    title: "Jane Cooper",
    thumbnail: "./img/o2.png",
    desc: "COO",
  },
  {
    id: 3,
    title: "Darrell Steward",
    thumbnail: "./img/o3.png",
    desc: "CTO",
  },
  {
    id: 4,
    title: "Dianne Russell",
    thumbnail: "./img/o4.png",
    desc: "CDO",
  }
]
export const provides = [
  {
    id: 1,
    title: "Host your NFTs",
    thumbnail: "./img/p1.png",
    desc: "Egestas tellus nunc proin amet tellus tincidunt lacus consequat. Ultrices",
  },
  {
    id: 2,
    title: "See your sales",
    thumbnail: "./img/p2.png",
    desc: "Integer ante non nunc, eget est justo vel semper nunc. Lacus ",
  },
  {
    id: 3,
    title: "Secure wallet",
    thumbnail: "./img/p3.png",
    desc: "Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et leo urna est.",
  },
  {
    id: 4,
    title: "No scam",
    thumbnail: "./img/p4.png",
    desc: "Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et leo urna est.",
  }
]

export const testimonials = [
  {
    id: 1,
    name: "Brooklyn Simmons",
    nameAcc: "@brooklynsimmons",
    desc: "Sit ut diam bibendum dolor. Ullamcorper pharetra nibh eget vitae pulvinar. Placerat sapien, dolor, aenean vivamus in tincidunt et. Mauris dolor vestibulum et lacus a ante orci.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 2,
    name: "Dianne Russell",
    nameAcc: "@DianneRussell",
    desc: "Eu luctus tincidunt vulputate praesent interdum proin. Magna gravida at pretium vitae. Viverra.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 3,
    name: "Eleanor Pena",
    nameAcc: "@EleanorPena",
    desc: "Amet quam velit nisl et et. Fusce ante facilisi vulputate eget aliquet mi sem eu vulputate.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 4,
    name: "Esther Howard",
    nameAcc: "@estherhhoward",
    desc: "Vitae tellus bibendum nibh integer auctor pretium sed. Sollicitudin tristique euismod elit.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 5,
    name: "Jane Cooper",
    nameAcc: "@JaneCooper",
    desc: "Eu eu eget lorem commodo sagittis enim in viverra. Urna egestas ipsum gravida tempor. Libero, consectetur urna in enim magnis. Est.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 6,
    name: "Jane Cooper",
    nameAcc: "@JaneCooper",
    desc: "Amet aliquam, volutpat nisl, duis sed at. Vehicula proin consectetur risus dictumst nec amet consequat at tempus. Ornare dapibus nunc fames nibh morbi viverra eu sed mattis.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 7,
    name: "Kristin Watson",
    nameAcc: "@KristinWatson",
    desc: "Lectus dolor fermentum gravida ut sit vel. Enim. Lorem ipsum will never be the same again so purchase Zeus UI now or web trying.",
    thumbnail: "./img/t1.png",
  },
  {
    id: 8,
    name: "Leslie Alexander",
    nameAcc: "@LeslieAlexander",
    desc: "Varius bibendum quis ipsum sit. Enim ante donec erat neque semper. Consectetur sed imperdiet tortor duis nulla aliquet at integer. ",
    thumbnail: "./img/t1.png",
  },
  {
    id: 9,
    name: "Darlene Robertson",
    nameAcc: "@DarleneRobertson",
    desc: "Imperdiet sed tellus tempor vitae elit a. Arcu a.",
    thumbnail: "./img/t1.png",
  },
]