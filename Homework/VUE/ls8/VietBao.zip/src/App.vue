<template>
  <div id="app">
    <TheHeader />
    <HomeBanner />
    <LogoBrand />
    <AboutUs />
    <OurTeam />
  </div>
</template>

<script>
import TheHeader from "./components/TheHeader.vue";
import HomeBanner from "./components/HomeBanner.vue";
import OurTeam from "./components/OurTeam.vue";
import LogoBrand from "./components/LogoBrand.vue";
import AboutUs from "./components/AboutUs.vue";

export default {
  name: "App",
  components: {
    TheHeader,
    HomeBanner,
    OurTeam,
    LogoBrand,
    AboutUs,
  },
};
</script>

<style lang="scss">
</style>
