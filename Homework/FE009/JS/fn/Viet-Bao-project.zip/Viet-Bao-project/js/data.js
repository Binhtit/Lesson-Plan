export const dataTickets = [
  {
    id: 1,
    ticketName: "Contact Email not Linked",
    customerName: "Tom Cruise",
    dateCreate: "on 24.05.2019",
    dateEnd: "May 26, 2019",
    hourEnd: "6:30 PM",
    status: "high"
  },
  {
    id: 2,
    ticketName: "Adding Images to Featured Posts",
    customerName: "Matt Damon",
    dateCreate: "on 24.05.2019",
    dateEnd: "May 26, 2019",
    hourEnd: "8:00 AM",
    status: "low"
  },
  {
    id: 3,
    ticketName: "When will I be charged this month?",
    customerName: "Robert Downey",
    dateCreate: "on 24.05.2019",
    dateEnd: "May 26, 2019",
    hourEnd: "7:30 PM",
    status: "high"
  },
  {
    id: 4,
    ticketName: "Payment not going through",
    customerName: "Christian Bale",
    dateCreate: "on 24.05.2019",
    dateEnd: "May 25, 2019",
    hourEnd: "5:00 PM",
    status: "normal"
  },
  {
    id: 5,
    ticketName: "Unable to add replies",
    customerName: "Henry Cavil",
    dateCreate: "on 24.05.2019",
    dateEnd: "May 25, 2019",
    hourEnd: "4:00 PM",
    status: "high"
  },
  {
    id: 6,
    ticketName: "Downtime since last week",
    customerName: "Chris Evans",
    dateCreate: "on 23.05.2019",
    dateEnd: "May 25, 2019",
    hourEnd: "2:00 PM",
    status: "normal"
  },
  {
    id: 7,
    ticketName: "Referral Bonus",
    customerName: "Sam Smith",
    dateCreate: "on 22.05.2019",
    dateEnd: "May 25, 2019",
    hourEnd: "11:30 AM",
    status: "low"
  },
  {
    id: 8,
    ticketName: "How do I change my password?",
    customerName: "Steve Rogers",
    dateCreate: "on 21.05.2019",
    dateEnd: "May 24, 2019",
    hourEnd: "1:00 PM",
    status: "normal"
  },
]