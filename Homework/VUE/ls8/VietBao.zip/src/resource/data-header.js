export const DATA_HEADER = [
  {
    id: 1,
    name: "user case",
    link: "/#",
    child: [
      {
        id: 10,
        name: "child1",
        link: "/3"
      },
      {
        id: 11,
        name: "child2",
        link: "/#"
      },

    ]
  },
  {
    id: 2,
    name: "resources",
    link: "/#",
  },
  {
    id: 3,
    name: "weekly demos",
    link: "/#",
  },
  {
    id: 4,
    name: "pricing",
    link: "/#",
  },
]