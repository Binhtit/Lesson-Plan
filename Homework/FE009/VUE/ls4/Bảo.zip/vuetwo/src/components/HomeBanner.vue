<template>
  <div class="banner">
    <h1 class="banner__title">
      Silika Helps <br />
      Marketing Agencies!
    </h1>
    <p class="banner__content">
      At nulla tristique facilisis augue. Lectus diam dignissim erat blandit
      pellentesque egestas <br />
      nulla a. Nulla consectetur nunc egestas metus pellentesque.
    </p>
    <div class="banner__btn">
      <a href="" class="banner__btn--started">Get Started</a>
      <a href="" class="banner__btn--how">How It Works</a>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss">
@import "../assets/scss/_variable.scss";
@import "../assets/scss/_mixin.scss";
@import "../assets/scss/_extend.scss";

.banner {
  padding: 293px 133px 208px;
  background-image: linear-gradient(
    to top right,
    #78bfd4,
    #a0c8d0,
    #fcdacc,
    #fee9de
  );
  &__title {
    color: $textColor;
    text-align: center;
    font-size: 64px;
    font-weight: 700;
  }
  &__content {
    text-align: center;
    margin: 30px 0 40px;
  }
  &__btn {
    @include flex-box(center, center);
    &--started {
      @include style-button($color--pink);
      margin-right: 20px;
    }
    &--how {
      @include style-button($color--lightGreen);
    }
  }
}
</style>