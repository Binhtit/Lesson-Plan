<template>
  <div id="app">
    <TheHeader />
    <HomeBanner />
  </div>
</template>

<script>
import TheHeader from "./components/TheHeader.vue";
import HomeBanner from "./components/HomeBanner.vue";

export default {
  name: "App",
  components: {
    TheHeader,
    HomeBanner,
  },
};
</script>

<style lang="scss">
</style>
