import { dataTickets } from "./data.js";

// $(document).ready(function () {

let SLTicket = $('.sl-tic').val() / 1
console.log(SLTicket);

if ($('#tab')) {
  $(function () {
    $("#tabs").tabs();
  });
}

window.handleAddTicket = handleAddTicket
window.handleEditTicket = handleEditTicket
window.sortTable = sortTable

let idTicCurrent = 0;
let $ticketList = $('.all-tickets table tbody')
renderTicket(dataTickets, SLTicket)

function renderStatusTicket(status) {
  if (status == "high") {
    return "high"
  } else if (status == "low") {
    return "low"
  } else {
    return "normal"
  }
}

$(document).ready(function () {
  // $( "#date-end-f-edit" ).datepicker();
  $("#date-end-f-edit").datepicker({
    dateFormat: "M dd, yy",
    monthNamesShort: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ],
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    currentText: "Today",
    closeText: "Close",
    minDate: new Date(),
  });
  $("#day-end-f-add").datepicker({
    dateFormat: "M dd, yy",
    monthNamesShort: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ],
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    currentText: "Today",
    closeText: "Close",
    minDate: new Date(),
  })

  // $("#date-end-f-edit").change(function () {
  //   const val = $('#date-end-f-edit').val()
  //   console.log('val', val);
  //   // setTimeout(() => {
  //   //   $('#date-end-f-edit').val("May 22, 2022")
  //   //   // $('#date-end-f-edit').val("Dec 05, 2022")
  //   // }, 2000);
  // });
});

$('.sl-tic').on('change', function () {
  SLTicket = $(this).val()
  console.log(SLTicket);
  renderTicket(dataTickets, SLTicket)
})


function renderTicket(arrTicket, SLTicket) {
  $ticketList.empty();
  console.log(arrTicket);
  // arrTicket.forEach((ticItem, idxTic) => {
  //   let ticketItem = document.createElement('tr');
  //   $(ticketItem).attr('data-id', ticItem.id)
  //   $(ticketItem).html(`
  //       <td class="ticket-detail d-flex align-items-center">
  //         <div class="avt">
  //           <img src="../img/r1.png" alt="">
  //         </div>
  //         <div class="text">
  //           <p class="ticket-name color-text-dark fw-bold">
  //             ${ticItem.ticketName}
  //           </p>
  //           <span class="ticket-time-edit color-text-light">
  //             Updated 1 day ago
  //           </span>
  //         </div>
  //       </td>
  //       <td class="customer-name">
  //         <p class="name color-text-dark fw-bold">${ticItem.customerName}</p>
  //         <span class="time color-text-light">${ticItem.dateCreate}</span>
  //       </td>
  //       <td class="date">
  //         <p class="day color-text-dark fw-bold">${ticItem.dateEnd}</p>
  //         <span class="hour color-text-light">${ticItem.hourEnd}</span>
  //       </td>
  //       <td class="priority">
  //         <span class="${renderStatusTicket(ticItem.status)}">${renderStatusTicket(ticItem.status)}</span>
  //       </td>
  //       <td class="methods">
  //         <div class="icon">
  //           <img src="../img/more-vertical.png" alt="">
  //           <div class="all-method">
  //             <span class="add" onclick="handleShowFormAdd()">
  //               <i class="fa-solid fa-plus"></i>
  //             </span>
  //             <span class="edit" onclick="handleShowFormEdit(${ticItem.id})">
  //               <i class="fa-regular fa-pen-to-square"></i>
  //             </span>
  //             <span class="delete" onclick="handleDeleteTicket(${ticItem.id})">
  //               <i class="fa-solid fa-trash"></i>
  //             </span>
  //           </div>
  //         </div>
  //       </td>
  //     `)
  //   $ticketList.append(ticketItem);
  //   if (SLTicket == idxTic) {
  //     // console.log('false');
  //     break;
  //     return false;
  //   }

  // });
  for (let ticItem = 0; ticItem < arrTicket.length; ticItem++) {
    let ticketItem = document.createElement('tr');
    $(ticketItem).attr('data-id', ticItem.id)
    $(ticketItem).html(`
        <td class="ticket-detail d-flex align-items-center">
          <div class="avt">
            <img src="../img/r1.png" alt="">
          </div>
          <div class="text">
            <p class="ticket-name color-text-dark fw-bold">
            ${arrTicket[ticItem].ticketName}
            </p>
            <span class="ticket-time-edit color-text-light">
              Updated 1 day ago
            </span>
          </div>
        </td>
        <td class="customer-name">
          <p class="name color-text-dark fw-bold">${arrTicket[ticItem].customerName}</p>
          <span class="time color-text-light">${arrTicket[ticItem].dateCreate}</span>
        </td>
        <td class="date">
          <p class="day color-text-dark fw-bold">${arrTicket[ticItem].dateEnd}</p>
          <span class="hour color-text-light">${arrTicket[ticItem].hourEnd}</span>
        </td>
        <td class="priority">
          <span class="${renderStatusTicket(arrTicket[ticItem].status)}">
            ${renderStatusTicket(arrTicket[ticItem].status)}
          </span>
        </td>
        <td class="methods">
          <div class="icon">
            <img src="../img/more-vertical.png" alt="">
            <div class="all-method">
              <span class="add" onclick="handleShowFormAdd()">
                <i class="fa-solid fa-plus"></i>
              </span>
              <span class="edit" onclick="handleShowFormEdit(${arrTicket[ticItem].id})">
                <i class="fa-regular fa-pen-to-square"></i>
              </span>
              <span class="delete" onclick="handleDeleteTicket(${arrTicket[ticItem].id})">
                <i class="fa-solid fa-trash"></i>
              </span>
            </div>
          </div>
        </td>
      `)
    $ticketList.append(ticketItem);
    if (SLTicket == ticItem + 1) {
      // console.log('false');
      break;

    }

  }

}

window.handleShowFormAdd = function () {
  $('.form-add').addClass('show')
}

window.handleShowFormEdit = function (idTic) {
  idTicCurrent = idTic
  $('.form-edit').addClass('show')
  const currentIdx = dataTickets.findIndex(val => val.id == idTic);
  let $ticName = $('#ticket-name-f-edit')
  let $dayEnd = $('#date-end-f-edit')
  let $hourEnd = $('#hour-end-f-edit')
  let $priority = $('#priority-f-edit')
  $ticName.val(dataTickets[currentIdx].ticketName)
  $hourEnd.val(dataTickets[currentIdx].hourEnd)
  $priority.val(dataTickets[currentIdx].status)
  $dayEnd.val(dataTickets[currentIdx].dateEnd)
}

window.handleHideFormAdd = function (params) {
  if (params == 'add') {
    $('.form-add').removeClass('show')
  } else {
    $('.form-edit').removeClass('show')
  }
}

window.handleDeleteTicket = function (idTodo) {
  const currentIdx = dataTickets.findIndex(val => val.id == idTodo);
  dataTickets.splice(currentIdx, 1)
  renderTicket(dataTickets)
}

window.addEventListener('click', function (e) {
  let target = e.target
  let parentTarget = target.parentNode
  if (parentTarget.classList.contains('show')) {
    parentTarget.classList.remove('show')
  } else {
    $('.methods .icon').removeClass('show');
    parentTarget.classList.add('show')
  }
})

function handleAddTicket() {
  let $valueTicketName = $('#ticket-name-f-add')
  let $valueDayEnd = $('#day-end-f-add').val()
  let $valueHourEnd = $('#hour-end-f-add')
  let $valuePriority = $('#priority-f-add')

  if ($valueTicketName.val().trim() && $valueDayEnd && $valueHourEnd.val().trim()) {
    let newTicket = {
      id: randomID(),
      ticketName: $valueTicketName.val().trim(),
      customerName: $('.user-admin .name').text(),
      dateCreate: getDateNow(),
      // dateEnd: formatDate($valueDayEnd),
      dateEnd: $valueDayEnd,
      hourEnd: $valueHourEnd.val().trim(),
      status: $valuePriority.val(),
    }
    dataTickets.push(newTicket);
  }
  renderTicket(dataTickets, SLTicket)
  $valueTicketName.val('')
  $valueHourEnd.val('')
  $valuePriority.val('normal')
  $('.form-add').removeClass('show')
}

function handleEditTicket() {
  console.log(idTicCurrent);
  const currentIdx = dataTickets.findIndex(val => val.id == idTicCurrent);
  dataTickets[currentIdx].ticketName = $('#ticket-name-f-edit').val()
  dataTickets[currentIdx].hourEnd = $('#hour-end-f-edit').val()
  dataTickets[currentIdx].status = $('#priority-f-edit').val()
  dataTickets[currentIdx].dateEnd = $("#date-end-f-edit").val()
  renderTicket(dataTickets, SLTicket);
  $('.form-edit').removeClass('show')
}

function randomID() {
  let d = new Date()
  return d.getTime()
}

function formatDate(str) {
  let m = parseInt(str.substring(5, 7))
  let month = ""
  let d = str.substring(8, 10)
  let y = str.substring(0, 4)
  switch (m) {
    case 1:
      month = "Jan";
      break;
    case 2:
      month = "Feb";
      break;
    case 3:
      month = "Mar";
      break;
    case 4:
      month = "Apr";
      break;
    case 5:
      month = "May";
      break;
    case 6:
      month = "Jun";
      break;
    case 7:
      month = "Jul";
      break;
    case 8:
      month = "Aug";
      break;
    case 9:
      month = "Sep";
      break;
    case 10:
      month = "Oct";
      break;
    case 11:
      month = "Nov";
      break;
    case 12:
      month = "Dec";
  }
  return month + ' ' + d + ' , ' + y
}

function getDateNow() {
  let d = new Date()
  let day = d.getDate() > 9 ? d.getDate() : "0" + d.getDate()
  let month = d.getMonth() + 1 > 9 ? d.getMonth() + 1 : "0" + d.getMonth() + 1
  let year = d.getFullYear()
  let fullTime = 'on ' + day + '.' + month + '.' + year
  return fullTime
}

function sortTable(number) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.querySelector("#tabs-tickets table");
  switching = true;
  /* Make a loop that will continue until
  no switching has been done: */
  while (switching) {
    // Start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /* Loop through all table rows (except the
    first, which contains table headers): */
    for (i = 1; i < (rows.length - 1); i++) {
      // Start by saying there should be no switching:
      shouldSwitch = false;
      /* Get the two elements you want to compare,
      one from current row and one from the next: */
      x = rows[i].getElementsByTagName("TD")[number - 1];
      y = rows[i + 1].getElementsByTagName("TD")[number - 1];
      // Check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        // If so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark that a switch has been done: */
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}