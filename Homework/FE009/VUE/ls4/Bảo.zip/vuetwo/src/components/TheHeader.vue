<template>
  <header class="header">
    <a href="/" id="header__logo">
      <img src="../assets/logo-silika.png" alt="" />
    </a>
    <ul class="header__nav">
      <li>
        <a href="#">
          user case
          <font-awesome-icon icon="fa-solid fa-chevron-down" />
        </a>
      </li>
      <li>
        <a href="#">
          resources
          <font-awesome-icon icon="fa-solid fa-chevron-down" />
        </a>
      </li>
      <li><a href="#">weekly demos</a></li>
      <li><a href="#">pricing</a></li>
    </ul>
    <div class="header__right">
      <a href="#" class="header__right--login">Login</a>
      <a href="" class="header__right--button">Get Started</a>
    </div>
  </header>
</template>

<script>
export default {};
</script>

<style lang="scss">
@import "../assets/scss/_variable.scss";
@import "../assets/scss/_mixin.scss";
@import "../assets/scss/_extend.scss";

.header {
  padding: 23px 133px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  &__nav {
    display: flex;
    align-items: center;
    & > li {
      margin-right: 24px;
      a {
        @extend .style-a;
      }
      &:last-child {
        margin-right: 0;
      }
    }
  }
  &__right {
    &--login {
      @extend .style-a;
    }
    &--button {
      @include style-button($color--lightGreen);
      margin-left: 16px;
    }
  }
}
</style>