const dataTodoList = [
  {
    id: 1,
    todoName: 'Learn VueJs',
    status: false,
    createAt: '15:38:01 28/11/2022'
  },
  {
    id: 2,
    todoName: 'Code a todo list',
    status: false,
    createAt: '15:39:01 28/11/2022'
  },
  {
    id: 3,
    todoName: 'Learn something else',
    status: false,
    createAt: '15:39:40 28/11/2022'
  }
]

let $btnAdd = $('.btn-add');
let $todoList = $('.todos');
let $checkbox = $('#checkbox')
let $dateNow = $('#date-now')

// $(function () {
//   $dateNow.datepicker();
// });

$btnAdd.on('click', function (e) {
  let $addContent = $('#add-content');
  let inputAddContent = $addContent.val()
  e.preventDefault()
  if (inputAddContent.trim()) {
    let newTodo = {
      id: dataTodoList.length + 1,
      todoName: inputAddContent.trim(),
      status: false,
      createAt: getValueInputDate()
    }
    dataTodoList.push(newTodo);
    $addContent.val('')
    $dateNow.val('')
  }
  renderTodo(dataTodoList);
})

function getValueInputDate() {
  let valueInputDate = ''
  if (!$dateNow.val().trim()) {
    valueInputDate = handleDate();
  } else {
    valueInputDate = $dateNow.val().trim()
  }
  return valueInputDate;
}

function handleCheck(idTodo) {
  const currentIdx = dataTodoList.findIndex(val => val.id == idTodo);
  dataTodoList[currentIdx].status = !dataTodoList[currentIdx].status
  renderTodo(dataTodoList)
}

function handleDelete(idTodo) {
  const currentIdx = dataTodoList.findIndex(val => val.id == idTodo);
  if (dataTodoList[currentIdx].status) {
    dataTodoList.splice(currentIdx, 1)
    renderTodo(dataTodoList)
  }
}

function handleDate() {
  let d = new Date();
  console.log(d);
  let month = d.getMonth() + 1;
  let day = d.getDate();

  let output =
    d.getHours() + ':' +
    d.getMinutes() + ':' +
    d.getSeconds() + ' ' +
    (day < 10 ? '0' : '') + day + '/' +
    (month < 10 ? '0' : '') + month + '/' +
    d.getFullYear();
  console.log(output);
  $dateNow.val(output)
  return output;
}

renderTodo(dataTodoList);
function renderTodo(dataTodoList) {
  let $todo = $('.todos');
  $todo.html('');
  dataTodoList.forEach(val => {
    let todoItem = document.createElement("div");
    $(todoItem).addClass('todo-item');
    todoItem.dataset.id = val.id
    if (val.status) {
      $(todoItem).addClass('checked')
    }
    $(todoItem).html(`
      <div class="text">
        <p class="todo-name">${val.todoName}</p>
        <span class="day">${val.createAt}</span>
      </div>
      <div class="todo-feature">
        <input onclick="handleCheck(${val.id})" class="check" type="checkbox" ${val.status ? "checked" : " "}>
        <div class="icon-trash" onclick="handleDelete(${val.id})">
          <i class="fa-solid fa-trash"></i>
        </div>
      </div>
    `)
    $todoList.append(todoItem);
  })
}

$checkbox.on('click', function () {
  $('.todos').toggleClass('sort')
})
