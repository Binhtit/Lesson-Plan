

export const DATA_OURTEAMS = [
  {
    id: 1,
    title: "Blog Content",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/Vector.svg'),
  },
  {
    id: 2,
    title: "Article",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/article.svg'),
  },
  {
    id: 3,
    title: "Content Writing",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/content.svg'),
  },
  {
    id: 4,
    title: "Seo",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/seo.svg'),
  },
  {
    id: 5,
    title: "Design",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/design.svg'),
  },
  {
    id: 6,
    title: "Coding",
    content: "Write optimized blog posts in a fraction of the time",
    icon: require('../assets/image/coding.svg'),
  },

]