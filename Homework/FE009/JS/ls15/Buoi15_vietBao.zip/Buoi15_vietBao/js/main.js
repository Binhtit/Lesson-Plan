import { collections, ourTeam, provides, testimonials } from "./data.js";

let collectionsList = document.querySelector('.collections-all');
let teamList = document.querySelector('.our-teams');
let provideList = document.querySelector('.provide');
let modal = document.querySelector('.modal-detail');
let modalAdd = document.querySelector('.modal-add');
let valueTitle = document.querySelector('.value-title');
let valueDesc = document.querySelector('.value-desc');
let valueSalary = document.querySelector('.value-salary');
let valueTitleAdd = document.querySelector('.value-title-add');
let valueDescAdd = document.querySelector('.value-desc-add');
let valueSalaryAdd = document.querySelector('.value-salary-add');
let popupUpdated = document.querySelector('.popup-updated');
let popupAdd = document.querySelector('.popup-added');
let testimonial = document.querySelector('.testimonials')
let idItem = '';

window.handleEdit = handleEdit;
window.handleSave = handleSave;
window.handleCloseModal = handleCloseModal;
window.handleAdd = handleAdd;
window.handleAddCollection = handleAddCollection;

renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)
renderTestimonials(testimonials, testimonial)

let searchTitle = document.querySelector('#search-title');
let employeeAPI = "https://dummy.restapiexample.com/api/v1/employees";

var newData = []

const xhttp = new XMLHttpRequest();

xhttp.onload = function () {
  const dataAPI = JSON.parse(this.response)
  console.log(dataAPI);
  newData = dataAPI.data
  renderCollections(newData, collections)
}

xhttp.open("GET", employeeAPI, false);
xhttp.send();

searchTitle.addEventListener('input', function () {
  let inputValue = this.value.trim().toLowerCase();
  let listItem = document.querySelectorAll('.collections-all .collection-item');

  listItem.forEach(item => {
    let titleItem = item.querySelector('.box-title').textContent.toLowerCase();
    if (!titleItem.includes(inputValue)) {
      item.classList.add('hidden')
    } else {
      item.classList.remove('hidden')
    }
  })
})

function handleSave() {
  newData[idItem - 1].employee_name = valueTitle.value
  newData[idItem - 1].employee_age = valueDesc.value
  newData[idItem - 1].employee_salary = valueSalary.value
  modal.classList.remove('show')
  popupUpdated.classList.add('show')
  renderCollections(newData, collections);
  setTimeout(removePopup, 2000);
}

function handleAddCollection() {
  console.log(valueTitle.value);
  if (valueTitleAdd.value) {
    const newCollection = {
      employee_age: valueDescAdd.value,
      employee_name: valueTitleAdd.value,
      employee_salary: valueSalaryAdd.value,
      id: newData.length + 1,
      profile_image: "",
    }
    newData.push(newCollection)
    valueTitleAdd.value = '';
    valueDescAdd.value = '';
    valueSalaryAdd.value = '';
    popupAdd.classList.add('show')
    handleCloseModal();
    renderCollections(newData, collections)
    setTimeout(removePopup, 2000);
  }
}

function getRandomIntImg(int) {
  return Math.floor(Math.random() * int);
}

function handleAdd() {
  modalAdd.classList.add('show')
}

function removePopup() {
  popupUpdated.classList.remove('show')
  popupAdd.classList.remove('show')
}

function handleCloseModal(params) {
  if (params == 'modalDetail') {
    modal.classList.remove('show')
  } else {
    modalAdd.classList.remove('show')
  }
}

function renderCollections(collections, arrImage) {
  console.log(collections);
  // let stringifyCol = JSON.stringify(collections)
  // console.log(stringifyCol);
  collectionsList.innerHTML = '';
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    collectionItem.classList.add('collection-item')
    collectionItem.dataset.id = val.id;
    collectionItem.innerHTML = `
      <div class="box-image">
        <img src="${arrImage[getRandomIntImg(9)].thumbnail}" alt="">
        <div class="btn btn-success btn-edit" onclick="handleEdit(${val.id})">
          Edit 
        </div>
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.employee_name}</h3>
        <div class="box-excerpt d-flex justify-content-center">
          <span class="mx-4">Age: ${val.employee_age}</span>
          <span>Salary: ${formatSalary(val.employee_salary)}</span>
        </div>
      </div>
    `
    collectionsList.appendChild(collectionItem);
  });
}

function formatSalary(number) {
  return new Intl.NumberFormat('vi').format(number)
}

function handleEdit(numberID) {
  // console.log(dataArr);
  console.log(numberID);
  // let arr = JSON.parse(dataArr)
  valueTitle.value = newData[numberID - 1].employee_name
  valueDesc.value = newData[numberID - 1].employee_age
  valueSalary.value = newData[numberID - 1].employee_salary
  idItem = numberID;
  modal.classList.add('show');
}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    teamItem.classList.add('item')
    teamItem.dataset.id = val.id;
    teamItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `
    ele.appendChild(teamItem);
  });
}

function renderTestimonials(array, ele) {
  array.forEach(val => {
    let testItem = document.createElement('div');
    testItem.classList.add('item')
    testItem.dataset.id = val.id;
    testItem.innerHTML = `
    <div class="top">
      <div class="avt">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="name">
        <div class="name-top">${val.name}</div>
        <div class="name-bottom">${val.nameAcc}</div>
      </div>
    </div>
    <div class="bottom">${val.desc}</div>
    `
    ele.appendChild(testItem);
  });
}