import Vue from 'vue'
import App from './App.vue'
import { library } from '@fortawesome/fontawesome-svg-core'
import { faHatWizard, faChevronDown } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import "./assets/scss/reset.scss"
import "./assets/scss/variable.scss"
import "./assets/scss/mixin.scss"
import "./assets/scss/extend.scss"

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')

library.add(faHatWizard, faChevronDown)
Vue.component('font-awesome-icon', FontAwesomeIcon)