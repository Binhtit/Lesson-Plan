$('.btn-eye').click(function () {
  // this.addClass('show')
  let inputPass = $('.input-pass input')
  inputPass.attr('type') == 'password' ? inputPass.attr('type', 'text') : inputPass.attr('type', 'password');
  $(this).toggleClass('show')
})

let $emailInput = $('#email-login')
let $passInput = $('#pass-login')
let isEmail = false;
let isPass = false;

$emailInput.on('input', function () {
  let valEmailInput = $(this).val().trim()
  let $resultInfoEmail = $('.result-info-email')
  if (valEmailInput == '') {
    $resultInfoEmail.text('Email không được để trống')
    $resultInfoEmail.addClass('text-danger').removeClass('text-success')
    isEmail = false;
  } else if (!valEmailInput.includes('@gmail.com')) {
    $resultInfoEmail.text('Email không được đúng định dạng')
    $resultInfoEmail.addClass('text-danger').removeClass('text-success')
    isEmail = false;
  } else if (valEmailInput.includes('@gmail.com')) {
    $resultInfoEmail.text('Email hợp lệ')
    $resultInfoEmail.addClass('text-success').removeClass('text-danger')
    isEmail = true;
  }
})

$passInput.on('input', function () {
  let valPassInput = $(this).val().trim()
  let $resultInfoEmail = $('.result-info-pass')
  if (valPassInput.length == 0) {
    $resultInfoEmail.text('Password không được để trống')
    $resultInfoEmail.addClass('text-danger').removeClass('text-success')
    isPass = false;
  } else if (valPassInput.length < 6) {
    $resultInfoEmail.text('Password phải lớn hơn 6 kí tự')
    $resultInfoEmail.addClass('text-danger').removeClass('text-success')
    isPass = false;
  } else {
    $resultInfoEmail.text('')
    $resultInfoEmail.removeClass('text-danger')
    isPass = true;
  }
})

function login() {
  if (isPass && isEmail) {
    console.log(1);
    $('.form-login').attr("action", "./pages/dashboard.html");
  } else {
    alert('Thông tin đăng nhập không hợp lệ. Vui lòng kiểm tra lại.')
  }
}