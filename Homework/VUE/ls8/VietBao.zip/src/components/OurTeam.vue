<template>
  <section class="container">
    <h2 class="title">Our Team</h2>
    <div class="content">
      <div class="content__item" v-for="ourTeam in ourTeams" :key="ourTeam.id">
        <div class="content__item--icon">
          <img :src="ourTeam.icon" />
        </div>
        <div class="content__item--text">
          <h3>{{ ourTeam.title }}</h3>
          <p>{{ ourTeam.content }}</p>
          <a href="#">
            Try Blog Content
            <span>
              <font-awesome-icon icon="fa-solid fa-right-long" />
            </span>
          </a>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { DATA_OURTEAMS } from "../resource/data-ourteam.js";

export default {
  data() {
    return {
      ourTeams: DATA_OURTEAMS,
    };
  },
  methods: {
    
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/_base.scss";

section {
  .content {
    @include flex-box(inherit, flex-start);
    flex-wrap: wrap;
    padding: 0 -15px;
    &__item {
      width: calc(100% / 3 - 30px);
      padding: 50px 35px;
      border-radius: 5px;
      border: 1px solid #f1f1f1;
      @include flex-box(flex-start, flex-start);
      margin: 0 15px 30px;
      &--text {
        padding-left: 40px;
        h3 {
          font-size: 20px;
          color: $textColor;
        }
        p {
          color: #7a8994;
          margin: 25px 0 20px;
        }
        a {
          font-size: 14px;
          color: $color--lightGreen;
        }
      }
    }
  }
}
</style> 