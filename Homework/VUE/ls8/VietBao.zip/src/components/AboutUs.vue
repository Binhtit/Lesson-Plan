<template>
  <section class="container">
    <h2 class="title">More About Us</h2>
    <div class="content">
      <div class="left">
        <h3>professional & team choose copy.ai</h3>
        <p>Odio dictum lacus augue nulla sit integer facilisis massa. Nec et tellus eu amet. Faucibus sit sit massa ullamcorper </p>
        <a href="#" class="">Get Started</a>
      </div>
      <div class="right">
        <img src="../assets/image/play.png" alt="">
      </div>
    </div>
  </section>  
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
@import "../assets/scss/_base.scss";

.content {
  @include flex-box(center, space-between);
  & > div {
    width: calc(50% - 30px);
  }
  .left {
    h3 {
      font-size: 40px;
      color: #322853;
      text-transform: capitalize;
    } 
    p {
      margin: 20px 0px 25px;
      line-height: 19px;
      color: #818181;
    }
    a {
      @include style-button(#f22e52);
      display: inline-block;
    }
  }
  .right {
    background: url('../assets/image/bg-about-us.png') no-repeat;
    min-height: 381px;
    background-size: cover;
    @include flex-box(center, center);
  }
}

</style>