import { collections, ourTeam, provides } from "./data.js";

let collectionsList = document.querySelector('.collections-all');
let teamList = document.querySelector('.our-teams');
let provideList = document.querySelector('.provide');
let modal = document.querySelector('.modal-detail');
let closeModal = document.querySelector('.modal-close');
let valueTitle = document.querySelector('.value-title')
let valueDesc = document.querySelector('.value-desc')
let btnSave = document.querySelector('.btn-save')
let popupUpdated = document.querySelector('.popup-updated')
let currentIdxArray = '';

renderCollections(collections)
renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)

window.addEventListener('click', function (e) {
  let valueClick = e.target

  if (valueClick.classList.contains('btn-edit')) {
    modal.classList.add('show');
  }

  if (valueClick.parentNode.parentNode.classList.contains('collection-item')) {

    let currentIdx = valueClick.parentNode.parentNode.getAttribute('data-id');
    currentIdxArray = currentIdx
    valueTitle.value = collections[currentIdx - 1].title
    valueDesc.value = collections[currentIdx - 1].desc
  }
})

btnSave.addEventListener('click', function () {
  collections[currentIdxArray - 1].title = valueTitle.value
  collections[currentIdxArray - 1].desc = valueDesc.value
  modal.classList.remove('show')
  popupUpdated.classList.add('show')
  renderCollections(collections);
  setTimeout(removePopup, 2000);
})

function removePopup() {
  popupUpdated.classList.remove('show')
}

closeModal.addEventListener('click', function () {
  modal.classList.remove('show')
})

function renderCollections(collections) {
  let listEleCollection = document.querySelectorAll('.collections-all .collection-item');
  for (let idx = 0; idx < listEleCollection.length; idx++) {
    listEleCollection[idx].remove();
  }
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    collectionItem.classList.add('collection-item')
    collectionItem.dataset.id = val.id;
    collectionItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
        <div class="btn btn-success btn-edit">
          Edit 
        </div>
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.title}</h3>
        <div class="box-excerpt">${val.desc}</div>
      </div>
    `
    collectionsList.appendChild(collectionItem);
  });
}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    teamItem.classList.add('item')
    teamItem.dataset.id = val.id;
    teamItem.innerHTML = `
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `
    ele.appendChild(teamItem);
  });
}