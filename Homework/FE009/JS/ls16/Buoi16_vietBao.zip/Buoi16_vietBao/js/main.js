import { collections, ourTeam, provides, testimonials } from "./data.js";

let collectionsList = $('.collections-all');
let teamList = $('.our-teams');
let provideList = $('.provide');
let modal = $('.modal-detail');
let modalAdd = $('.modal-add');
let valueTitle = $(".value-title");
let valueDesc = $('.value-desc');
let valueSalary = $('.value-salary');
let valueTitleAdd = $('.value-title-add');
let valueDescAdd = $('.value-desc-add');
let valueSalaryAdd = $('.value-salary-add');
let popupUpdated = $('.popup-updated');
let popupAdd = $('.popup-added');
let testimonial = $('.testimonials')
let idItem = '';

window.handleEdit = handleEdit;
window.handleSave = handleSave;
window.handleCloseModal = handleCloseModal;
window.handleAdd = handleAdd;
window.handleAddCollection = handleAddCollection;

renderTeamAndProvide(ourTeam, teamList)
renderTeamAndProvide(provides, provideList)
renderTestimonials(testimonials, testimonial)

let searchTitle = $('#search-title');
// let employeeAPI = "https://dummy.restapiexample.com/api/v1/employees";

var newData = []

$(function () {
  const url = "https://dummy.restapiexample.com/api/v1/employees"
  $.ajax({
    url,
    success: function (response) {
      if (response.status === 'success') {
        const dataAPI = response.data
        newData = dataAPI
        renderCollections(newData, collections)
      }
    }
  });
})

searchTitle.on('input', function () {
  var inputValue = $(this).val().trim().toLowerCase();
  $(".collections-all .collection-item").filter(function () {
    $(this).toggle($(this).text().toLowerCase().indexOf(inputValue) > -1)
  });
});

function handleSave() {
  newData[idItem - 1].employee_name = valueTitle.val()
  newData[idItem - 1].employee_age = valueDesc.val()
  newData[idItem - 1].employee_salary = valueSalary.val()
  modal.removeClass('show')
  popupUpdated.addClass('show')
  renderCollections(newData, collections);
  setTimeout(removePopup, 2000);
}

function handleAddCollection() {
  console.log(valueTitleAdd.val());
  if (valueTitleAdd.val()) {
    const newCollection = {
      employee_age: valueDescAdd.val(),
      employee_name: valueTitleAdd.val(),
      employee_salary: valueSalaryAdd.val(),
      id: newData.length + 1,
      profile_image: "",
    }
    newData.push(newCollection)
    valueTitleAdd.val('')
    valueDescAdd.val('')
    valueSalaryAdd.val('')
    popupAdd.addClass('show')
    handleCloseModal();
    renderCollections(newData, collections)
    setTimeout(removePopup, 2000);
  }
}

function getRandomIntImg(int) {
  return Math.floor(Math.random() * int);
}

function handleAdd() {
  modalAdd.addClass('show')
}

function removePopup() {
  popupUpdated.removeClass('show')
  popupAdd.removeClass('show')
}

function handleCloseModal(params) {
  if (params == 'modalDetail') {
    modal.removeClass('show')
  } else {
    modalAdd.removeClass('show')
  }
}

function renderCollections(collections, arrImage) {
  collectionsList.empty();
  console.log(collections);
  collections.forEach(val => {
    let collectionItem = document.createElement('div');
    $(collectionItem).addClass('collection-item')
    $(collectionItem).attr('data-id', val.id)
    $(collectionItem).html(`
      <div class="box-image">
        <img src="${arrImage[getRandomIntImg(9)].thumbnail}" alt="">
        <div class="btn btn-success btn-edit" onclick="handleEdit(${val.id})">
          Edit 
        </div>
      </div>
      <div class="box-text">
        <h3 class="box-title">${val.employee_name}</h3>
        <div class="box-excerpt d-flex justify-content-center">
          <span class="mx-4">Age: ${val.employee_age}</span>
          <span>Salary: ${formatSalary(val.employee_salary)}</span>
        </div>
      </div>
    `)
    $(collectionsList).append(collectionItem);
  });
}

function formatSalary(number) {
  return new Intl.NumberFormat('vi').format(number)
}

function handleEdit(numberID) {
  // console.log(dataArr);
  console.log(numberID);
  // let arr = JSON.parse(dataArr)
  valueTitle.val(newData[numberID - 1].employee_name)
  valueDesc.val(newData[numberID - 1].employee_age)
  valueSalary.val(newData[numberID - 1].employee_salary)
  idItem = numberID;
  $(modal).addClass('show');
}

function renderTeamAndProvide(array, ele) {
  array.forEach(val => {
    let teamItem = document.createElement('div');
    $(teamItem).addClass('item')
    $(teamItem).attr('data-id', val.id)
    $(teamItem).html(`
      <div class="box-image">
        <img src="${val.thumbnail}" alt="">
      </div>
      <div class="box-text">
        <h3 class="title">${val.title}</h3>
        <p class="desc">${val.desc}</p>
      </div>
    `)
    $(ele).append(teamItem);
  });
}

function renderTestimonials(array, ele) {
  array.forEach(val => {
    let testItem = document.createElement('div');
    $(testItem).addClass('item')
    $(testItem).attr('data-id', val.id)
    $(testItem).html(`
      <div class="top">
        <div class="avt">
          <img src="${val.thumbnail}" alt="">
        </div>
        <div class="name">
          <div class="name-top">${val.name}</div>
          <div class="name-bottom">${val.nameAcc}</div>
        </div>
      </div>
      <div class="bottom">${val.desc}</div>
    `)
    $(ele).append(testItem);
  });
}