const dataTodoList = [
  {
    id: 1,
    todoName: 'Learn VueJs',
    status: false,
  },
  {
    id: 2,
    todoName: 'Code a todo list',
    status: false,
  },
  {
    id: 3,
    todoName: 'Learn something else',
    status: false,
  }
]

let btnAdd = document.querySelector('.btn-add');
let todoList = document.querySelector('.todos');
let checkbox = document.getElementById('checkbox')


btnAdd.addEventListener('click', function (e) {
  let addContent = document.querySelector('#add-content');
  let inputAddContent = addContent.value
  e.preventDefault()
  console.log(addContent);
  if (inputAddContent.trim()) {
    let newTodo = {
      id: dataTodoList.length + 1,
      todoName: inputAddContent.trim(),
      status: false,
    }
    dataTodoList.push(newTodo);
  }
  addContent.value = ''
  renderTodo(dataTodoList);
})

document.addEventListener('click', function (e) {
  const target = e.target
  if (target.classList.contains('check')) {
    const id = target.parentNode.parentNode.dataset.id;
    const currentIdx = dataTodoList.findIndex(val => val.id == id);
    dataTodoList[currentIdx].status = !dataTodoList[currentIdx].status
    renderTodo(dataTodoList)
  }
  if (target.parentNode.classList.contains('icon-trash')) {
    const id = target.parentNode.parentNode.parentNode.dataset.id;
    const currentIdx = dataTodoList.findIndex(val => val.id == id);
    if (dataTodoList[currentIdx].status) {
      dataTodoList.splice(currentIdx, 1)
      // dataTodoList = dataTodoList.filter(val => val.id != dataTodoList[currentIdx].id)
      renderTodo(dataTodoList)
    }
  }
})

renderTodo(dataTodoList);
function renderTodo(dataTodoList) {
  let todo = document.querySelectorAll('.todos .todo-item');
  for (let idx = 0; idx < todo.length; idx++) {
    todo[idx].remove();
  }
  dataTodoList.forEach(val => {
    let todoItem = document.createElement("div");
    todoItem.classList.add('todo-item');
    todoItem.dataset.id = val.id
    if (val.status) {
      todoItem.classList.add('checked')
    }
    todoItem.innerHTML = `
      <span class="todo-name">${val.todoName}</span>
      <div class="todo-feature">
        <input class="check" type="checkbox" ${val.status ? "checked" : " "}>
        <div class="icon-trash">
          <i class="fa-solid fa-trash"></i>
        </div>
      </div>
    `
    todoList.appendChild(todoItem);
  })
}

checkbox.addEventListener('click', function () {
  document.querySelector('.todos').classList.toggle('sort')
})
