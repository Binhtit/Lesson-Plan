export const collections = [
  {
    id: 1,
    title: "Moonbirds",
    thumbnail: "./img/c1.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 2,
    title: "Clone X - X Takashi Murakami",
    thumbnail: "../img/c2.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 3,
    title: "Mutant Ape Yacht Club",
    thumbnail: "../img/c3.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  },
  {
    id: 4,
    title: " 'MOAR' by Joan Cornella",
    thumbnail: "../img/c4.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 5,
    title: "Doodles",
    thumbnail: "../img/c5.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 6,
    title: "KIWAMI Genesis",
    thumbnail: "../img/c6.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  },
  {
    id: 7,
    title: "Arcade Land",
    thumbnail: "../img/c7.png",
    desc: "Faucibus odio elementum nulla venenatis, libero. Ullamcorper duis fringilla pulvinar nibh diam sit.",
  },
  {
    id: 8,
    title: "Goons of Balatroon",
    thumbnail: "../img/c8.png",
    desc: "Magna in condimentum praesent pretium vitae mattis facilisis nunc. Lectus in ac ac.",
  },
  {
    id: 9,
    title: "Meta Toy DragonZ",
    thumbnail: "./img/c9.png",
    desc: "Sit aenean porttitor sit lectus. Adipiscing egestas etiam eget cursus nulla risus euismod. Netus.",
  }
]
export const ourTeam = [
  {
    id: 1,
    title: "Guy Hawkins",
    thumbnail: "./img/o1.png",
    desc: "CEO",
  },
  {
    id: 2,
    title: "Jane Cooper",
    thumbnail: "./img/o2.png",
    desc: "COO",
  },
  {
    id: 3,
    title: "Darrell Steward",
    thumbnail: "./img/o3.png",
    desc: "CTO",
  },
  {
    id: 4,
    title: "Dianne Russell",
    thumbnail: "./img/o4.png",
    desc: "CDO",
  }
]
export const provides = [
  {
    id: 1,
    title: "Host your NFTs",
    thumbnail: "./img/p1.png",
    desc: "Egestas tellus nunc proin amet tellus tincidunt lacus consequat. Ultrices",
  },
  {
    id: 2,
    title: "See your sales",
    thumbnail: "./img/p2.png",
    desc: "Integer ante non nunc, eget est justo vel semper nunc. Lacus ",
  },
  {
    id: 3,
    title: "Secure wallet",
    thumbnail: "./img/p3.png",
    desc: "Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et leo urna est.",
  },
  {
    id: 4,
    title: "No scam",
    thumbnail: "./img/p4.png",
    desc: "Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et leo urna est.",
  }
]