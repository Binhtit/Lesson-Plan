<template>
  <div id="app">
    <TheHeader />
    <HomeBanner />
  </div>
</template>

<script>
import TheHeader from "./components/TheHeader.vue";
import HomeBanner from "./components/HomeBanner.vue";

export default {
  name: "App",
  components: {
    TheHeader,
    HomeBanner,
  },
};
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
  font-family: "Inter", sans-serif;
  box-sizing: border-box;
}

li {
  list-style: none;
}
a {
  text-decoration: none;
}
.container {
  width: calc(100% - 266px);
  margin: 0 auto;
}
</style>
