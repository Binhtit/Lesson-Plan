<template>
  <section class="container">
    <div class="logo">
      <img src="../assets/image/adobe.png" alt="">
    </div>
    <div class="logo">
      <img src="../assets/image/mosaic.png" alt="">
    </div>
    <div class="logo">
      <img src="../assets/image/colab.png" alt="">
    </div>
    <div class="logo">
      <img src="../assets/image/holtzman.png" alt="">
    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
@import "../assets/scss/_base.scss";

section {
  @include flex-box(center, center);
  padding: 100px 0 0;
  .logo {
    width: 25%;
    text-align: center;
    img {
      max-width: 100%;
    }
  }
}


</style>